kaboom()

loadBean()

let score = 0


scene("menu", () => {
  
  add([
    text("START"),
    "startButton",
    pos(200,200),
    color(0,255,50),
    area()
  ])
  
  onClick("startButton",() => {
    go("game")
  })
  
})

go("menu")

scene("game",() => {
  
  let hp = 3
  
  const player = add([
  sprite("bean", {
    width: 30,
    height: 30,
  }),
    pos(50,50),
    body(),
    area(),
      ])
  
  player.onUpdate(() => [
  //camPos(player.pos)
     
    ])
     
  
  onKeyDown("d", () => {
  player.move(350,0)
})

onKeyDown("a", () => {
  player.move(-350,0)
})
  
  onKeyPress("w", () => {
  player.jump()
    
  })
  
  
  

 
    

  
  })



